package com.matthewlane;

public class DoMath {
	public int doAddition(int x, int y) {
		return x + y;
	}

	public int doMultiplication(int x, int y) {
		return x * y;
	}
}